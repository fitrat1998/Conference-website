<!DOCTYPE html>
	<html>
	<head>
		<title>Reset password</title>
	</head>
	<style type="text/css">
		body {
			margin: auto 0px;
			padding: 0px;

		}

		 p,input	{
			margin-left: 330px !important;
			align-items: center !important;

		}
	</style>
	<body>
	
    <div>
	<form action="" method="post" id="reset">
		<h1 align="center">Enter your email</h1><br>
		<p><input type="email" name="email" placeholder="Enter your email"></p>
		<p><input type="submit" name="sub">	</p>
	</form>
   </div>

   <?php include'js.php';?>
	</body>
	</html>
