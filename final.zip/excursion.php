<?php
 session_start();
 include 'config.php';

 include 'header.php';
?>


<br><br><br>

<h4 style="text-align: center;">You can get some information about our excursion by downloading the following file :</h4>
<p style="text-align: center;"><a href="info.docx">download</a></p>

<br><br><br>
  <hr>
  <?php include"footer.php";?>