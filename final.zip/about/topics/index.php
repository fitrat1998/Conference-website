<?php

//header section
include'header.php';

//main section
include'main.php';

//footer section

include'footer.php';

?>