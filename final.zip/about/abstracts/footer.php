  <footer class="container ">
  	        <div class="reponsive__footer">
            <p class="">
            <a href="javascript:void();" data-target="#termsScrollable" data-toggle="modal" href="#" style="color:#008080;">Terms of use</a>
            <b style="margin-left: 300px;">Copyright &copy; 2022 &middot; SISM-2023 Organizers &middot;</b>
            <a href="#" style="margin-left: 300px; color:#008080;" >Back to top</a>
            </p>
        </div>

        <div class="responsive-menu-footer">
        	<b style="copyright">Copyright &copy; 2022 &middot; SISM-2023 Organizers &middot;</b><br>
 
        	<a href="javascript:void();" data-target="#termsScrollable" data-toggle="modal" href="#" style="color:#008080;">Terms of use</a><br>
        	<span style="justify-content:right!important; color:#008080; "> <a href="#" style=" color:#008080;" >Back to top</a></span>
        
        </div>	
  </footer>
 </div>
</body>
</html>