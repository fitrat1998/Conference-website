<?php
  include'header.php';
?>



<div class="container">
  <h1 align="center">Programm</h1><br>
<div class="col-md-12">
<table  class="table table-hover ml">
  <tbody>
    <tr>
      <th style="">Registration</th>
      <td style="">July 1</td>
      <td style="">9 <sup>00</sup> - 22 <sup>00</sup></td>
    </tr>
     <tr>
      <th style="">Welcome party</th>
      <td style="">July 1</td>
      <td style="">19 <sup>00</sup> - 22 <sup>00</sup></td>
    </tr>
    <tr>
      <th style="">Opening ceremony </th>
      <td style=""> July 2</td>
      <td style="">9 <sup>00</sup> - 9 <sup>30</sup></td>
    </tr>
    <tr>
      <th style="">Conference dinner</th>
      <td style=""> July 4</td>
      <td style="">19 <sup>00</sup></td>
    </tr>
    <tr>
      <th style="">Closing</th>
      <td style=""> July 5</td>
      <td style="">12 <sup>30</sup> </td>
    </tr>
    <tr>
      <th style="">Excursion to Bukhara</th>
      <td style=""> July 6</td>
    </tr>
  </tbody>
</table>
</div><br>
</div>

<br>
<hr>
<?php 
  include"footer.php";
?>